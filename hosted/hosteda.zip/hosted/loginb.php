<?php
header("location: /hosted/loginb.html");
?>