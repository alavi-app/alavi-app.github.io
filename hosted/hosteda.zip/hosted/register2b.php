<?php
header("location: /hosted/register2b.html");
?>