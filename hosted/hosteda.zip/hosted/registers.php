<?php
  $email=$_REQUEST["email"];
  $balance="10";
  $password=$_REQUEST["password"];
  $cata=$balance." ".$email ;
  $fula=$password.".txt";
  $balances="Balance";
  $emails="email";
  $passwords="password";
  setcookie($balances, $balance, time() +(86400 * 30), "/");
  setcookie($emails, $email, time() +(86400 * 30), "/");
  setcookie($passwords, $password, time() +(86400 * 30), "/");
function register(){
   $email=$_REQUEST["email"];
  $balance="0";
  $password=$_REQUEST["password"];
  $cata=$balance." ".$email ;
  $fula=$password.".txt";
  file_put_contents($fula, $cata);
}
register();
$script="<script>"."location.href='./register2b.php'</script>";
$scripts="<script>"."location.href='./after loginb.php'</script>";
$cool=$password.".txt";
if (!0){
    print $scripts;
}else{
  print $script;
}
?>